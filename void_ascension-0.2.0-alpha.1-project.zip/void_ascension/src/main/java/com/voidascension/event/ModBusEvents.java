package com.voidascension.event;

import com.voidascension.VoidAscension;
import com.voidascension.config.VoidConfig;
import com.voidascension.data.VoidPlayerData;
import com.voidascension.evolution.EvolutionTable;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.config.ModConfigEvent;

/** Mod-bus registration: capability type and config validation. */
@Mod.EventBusSubscriber(modid = VoidAscension.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModBusEvents {

    @SubscribeEvent
    public static void registerCaps(RegisterCapabilitiesEvent event) {
        event.register(VoidPlayerData.class);
    }

    @SubscribeEvent
    public static void onConfigLoad(ModConfigEvent.Loading event) { validate(event.getConfig()); }

    @SubscribeEvent
    public static void onConfigReload(ModConfigEvent.Reloading event) { validate(event.getConfig()); }

    private static void validate(ModConfig config) {
        if (config.getSpec() == VoidConfig.SERVER_SPEC) EvolutionTable.validateConfiguredTable();
    }

    private ModBusEvents() {}
}
