package com.voidascension.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/** Rebindable key mappings (Options > Controls > Key Binds > VOID: ASCENSION). */
public final class VoidKeyMappings {
    public static final String CATEGORY = "key.categories.void_ascension";

    public static final KeyMapping OPEN_PROGRESSION = new KeyMapping("key.void_ascension.open_progression",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY);
    public static final KeyMapping VOID_DASH = new KeyMapping("key.void_ascension.void_dash",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY);

    private VoidKeyMappings() {}
}
