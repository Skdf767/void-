package com.voidascension.client;

import com.voidascension.VoidAscension;
import com.voidascension.ability.VoidAbilities;
import com.voidascension.data.ClientVoidData;
import com.voidascension.item.VoidCoreItem;
import com.voidascension.network.UseAbilityPacket;
import com.voidascension.network.VoidNetwork;
import com.voidascension.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Client-only registration and input handling. */
public final class ClientEvents {

    @Mod.EventBusSubscriber(modid = VoidAscension.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent
        public static void clientSetup(FMLClientSetupEvent event) {
            event.enqueueWork(() -> ItemProperties.register(ModItems.VOID_CORE.get(), VoidAscension.id("bound"),
                    (stack, level, entity, seed) -> VoidCoreItem.isBound(stack) ? 1.0F : 0.0F));
        }

        @SubscribeEvent
        public static void registerOverlays(RegisterGuiOverlaysEvent event) {
            event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "void_status", VoidHudOverlay.INSTANCE);
        }

        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(VoidKeyMappings.OPEN_PROGRESSION);
            event.register(VoidKeyMappings.VOID_DASH);
        }

        private ModBus() {}
    }

    @Mod.EventBusSubscriber(modid = VoidAscension.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;
            while (VoidKeyMappings.OPEN_PROGRESSION.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new VoidProgressionScreen());
            }
            while (VoidKeyMappings.VOID_DASH.consumeClick()) {
                // The server validates unlock, cooldown, Essence and state and replies with feedback.
                if (VoidNetwork.CHANNEL != null) VoidNetwork.CHANNEL.sendToServer(new UseAbilityPacket(VoidAbilities.VOID_DASH.id()));
            }
        }

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
            ClientVoidData.clear();
        }

        private ForgeBus() {}
    }

    private ClientEvents() {}
}
