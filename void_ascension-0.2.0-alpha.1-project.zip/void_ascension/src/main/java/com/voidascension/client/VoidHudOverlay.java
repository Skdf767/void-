package com.voidascension.client;

import com.voidascension.ability.AbilityDefinition;
import com.voidascension.ability.AbilityService;
import com.voidascension.ability.VoidAbilities;
import com.voidascension.config.HudAnchor;
import com.voidascension.config.VoidConfig;
import com.voidascension.core.CoreService;
import com.voidascension.data.ClientVoidData;
import com.voidascension.data.VoidPlayerData;
import com.voidascension.evolution.EvolutionRequirements;
import com.voidascension.evolution.EvolutionTable;
import com.voidascension.progression.ProgressionService;
import com.voidascension.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import org.jetbrains.annotations.Nullable;

import java.util.Locale;

/**
 * Permanent Void HUD panel (default: bottom-right). Shows branding, tier, Evolution Level + XP bar, Essence, the next
 * tier's requirements with a readiness bar, the Void Dash cooldown and a flashing warning when the server denies an
 * ability (e.g. not enough Essence). Display only: everything comes from {@link ClientVoidData}, which is filled by
 * server packets; nothing here is sent back or trusted.
 * <p>
 * Allocation: all text components are cached and rebuilt only when the synced data changes ({@link
 * ClientVoidData#revision()}), when a new denial arrives, or at most every few ticks for the cooldown / core-carried
 * state. A frame with unchanged state only issues draw calls.
 */
public final class VoidHudOverlay implements IGuiOverlay {
    public static final VoidHudOverlay INSTANCE = new VoidHudOverlay();

    private static final int PAD = 4, ICON = 16, LINE = 10, MIN_W = 112;
    private static final int BG = 0xC0100018, BORDER = 0xA07B2CBF, ACCENT = 0xFF9D4EDD;
    private static final int BRAND = 0xC77DFF, WHITE = 0xFFFFFF, SOFT = 0xD8C8F0, MUTED = 0xA49CB4;
    private static final int READY = 0x7FFFD4, WARN = 0xFF6B6B, BAR_BG = 0xFF2A0E3F;
    private static final int WARNING_TICKS = 60;
    /** Distance from the screen bottom that keeps the hotbar, status bars and action-bar message visible. */
    static final int LIFTED_BOTTOM = 76;

    // ---- cache (client thread only) ----
    private int cachedRevision = Integer.MIN_VALUE;
    private long cachedBucket = Long.MIN_VALUE;
    private int cachedFeedbackSerial = -1;
    private long warningStart;
    @Nullable private ItemStack icon;
    private boolean dormant;
    private Component brand, tierLine, essenceLine, nextLine, reqLine, dashLine, warnLine;
    private int reqColor, dashColor;
    private float xpFrac, evoFrac;
    private int panelW, panelH;

    private VoidHudOverlay() {}

    @Override
    public void render(ForgeGui gui, GuiGraphics g, float partialTick, int screenWidth, int screenHeight) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || mc.level == null || mc.options.hideGui || mc.options.renderDebug) return;
        if (!VoidConfig.client(VoidConfig.HUD_ENABLED)) return;

        long now = mc.level.getGameTime();
        refresh(mc, player, now);
        if (dormant && !VoidConfig.client(VoidConfig.HUD_SHOW_DORMANT)) return;

        boolean warning = warnLine != null && now - warningStart < WARNING_TICKS && now >= warningStart;
        int h = panelH + (warning ? LINE : 0);
        int w = panelW;

        // ---- position ----
        HudAnchor anchor = VoidConfig.client(VoidConfig.HUD_ANCHOR);
        int ox = VoidConfig.client(VoidConfig.HUD_OFFSET_X), oy = VoidConfig.client(VoidConfig.HUD_OFFSET_Y);
        int x0 = anchor.right ? screenWidth - w - ox : ox;
        int y0 = anchor.bottom ? screenHeight - h - oy : oy;
        if (anchor.bottom) {
            // Hotbar (182) + offhand slot / attack indicator; health, food, armor and air rows sit above it, and the
            // vanilla action-bar message is drawn at screenHeight - 72..-63. On narrow windows the panel would cover
            // them, so it is lifted above that whole band (found in a real client run at 854x480, GUI scale 2).
            int cx = screenWidth / 2, left = cx - 91 - 30, right = cx + 91 + 30;
            if (x0 < right && x0 + w > left) y0 = Math.min(y0, screenHeight - LIFTED_BOTTOM - h);
        }
        x0 = Math.max(0, Math.min(x0, screenWidth - w));
        y0 = Math.max(0, Math.min(y0, screenHeight - h));

        // ---- panel ----
        g.fill(x0, y0, x0 + w, y0 + h, BG);
        boolean flashOn = warning && ((now - warningStart) / 5) % 2 == 0;
        g.renderOutline(x0, y0, w, h, flashOn ? 0xFFFF5555 : BORDER);
        g.fill(x0, y0 + 1, x0 + 2, y0 + h - 1, flashOn ? 0xFFFF5555 : ACCENT);

        Font font = mc.font;
        int x = x0 + PAD + 1, y = y0 + PAD;
        if (icon != null) g.renderItem(icon, x, y);
        int tx = x + ICON + 3;
        g.drawString(font, brand, tx, y, BRAND, true);
        g.drawString(font, tierLine, tx, y + LINE - 1, WHITE, true);
        y += ICON + 3;
        if (dormant) return;

        int innerW = w - 2 * PAD - 1;
        bar(g, x, y, innerW, 2, xpFrac, 0xFFC77DFF);
        y += 5;
        g.drawString(font, essenceLine, x, y, SOFT, true);
        y += LINE;
        g.drawString(font, nextLine, x, y, MUTED, true);
        y += LINE;
        if (reqLine != null) {
            g.drawString(font, reqLine, x, y, reqColor, true);
            y += LINE;
        }
        bar(g, x, y, innerW, 3, evoFrac, evoFrac >= 1F ? 0xFF7FFFD4 : ACCENT);
        y += 6;
        if (dashLine != null) {
            g.drawString(font, dashLine, x, y, dashColor, true);
            y += LINE;
        }
        if (warning) g.drawString(font, warnLine, x, y, WARN, true);
    }

    private static void bar(GuiGraphics g, int x, int y, int w, int h, float frac, int color) {
        g.fill(x, y, x + w, y + h, BAR_BG);
        int fw = (int) (w * Math.max(0F, Math.min(1F, frac)));
        if (fw > 0) g.fill(x, y, x + fw, y + h, color);
    }

    // ------------------------------------------------------------------ cache

    private void refresh(Minecraft mc, Player player, long now) {
        if (icon == null) icon = new ItemStack(ModItems.VOID_CORE.get());
        VoidPlayerData d = ClientVoidData.get();

        ClientVoidData.Feedback fb = ClientVoidData.feedback();
        if (fb != null && fb.serial() != cachedFeedbackSerial) {
            cachedFeedbackSerial = fb.serial();
            warningStart = now;
            warnLine = warning(fb);
            cachedBucket = Long.MIN_VALUE; // re-measure width
        }

        // Cooldown text has 0.1 s resolution -> rebuild every 2 ticks while a cooldown runs, else every 10 ticks.
        long dashCd = d.isInitialized() ? AbilityService.cooldownRemaining(d, VoidAbilities.VOID_DASH.id(), now) : 0;
        long bucket = dashCd > 0 ? now / 2 : now / 10;
        if (ClientVoidData.revision() == cachedRevision && bucket == cachedBucket) return;
        cachedRevision = ClientVoidData.revision();
        cachedBucket = bucket;

        brand = Component.translatable("hud.void_ascension.brand");
        Font font = mc.font;
        dormant = !d.isInitialized();
        if (dormant) {
            tierLine = Component.translatable("hud.void_ascension.dormant");
            panelW = Math.max(MIN_W, ICON + 3 + Math.max(font.width(brand), font.width(tierLine)) + 2 * PAD + 1);
            panelH = ICON + 2 * PAD + 3;
            return;
        }

        tierLine = Component.translatable("hud.void_ascension.tier_level", d.getTier().displayName(), d.getEvolutionLevel());
        xpFrac = levelProgress(d);
        essenceLine = Component.translatable("hud.void_ascension.essence", d.getEssence());

        EvolutionRequirements.Check c = clientCheck();
        if (c.next() == null) {
            nextLine = Component.translatable("hud.void_ascension.max");
            reqLine = null;
            evoFrac = 1F;
        } else {
            nextLine = Component.translatable("hud.void_ascension.next", c.next().displayName());
            boolean levelOk = c.isMet(EvolutionRequirements.Requirement.EVOLUTION_LEVEL);
            boolean essenceOk = c.isMet(EvolutionRequirements.Requirement.VOID_ESSENCE);
            if (c.eligible()) {
                reqLine = Component.translatable("hud.void_ascension.ready", VoidKeyMappings.OPEN_PROGRESSION.getTranslatedKeyMessage());
                reqColor = READY;
            } else if (levelOk && essenceOk) {
                reqLine = Component.translatable("hud.void_ascension.need_core");
                reqColor = 0xFFD36B;
            } else {
                // Current/required numbers make the state readable without relying on colour.
                reqLine = Component.translatable("hud.void_ascension.requirements",
                        c.level(), c.requiredLevel(), c.essence(), c.requiredEssence());
                reqColor = essenceOk ? MUTED : 0xE0A0FF;
            }
            evoFrac = readiness(c);
        }

        AbilityDefinition dash = VoidAbilities.VOID_DASH;
        if (AbilityService.isUnlocked(d, dash)) {
            int cost = AbilityService.activeImpl(dash.id()).map(a -> a.essenceCost()).orElse(0);
            if (dashCd > 0) {
                dashLine = Component.translatable("hud.void_ascension.cooldown", dash.displayName(),
                        String.format(Locale.ROOT, "%.1f", dashCd / 20.0));
                dashColor = MUTED;
            } else if (d.getEssence() < cost) {
                // Off cooldown but unaffordable: say so instead of "ready" (seen in a real client run).
                dashLine = Component.translatable("hud.void_ascension.ability_needs_essence", dash.displayName(), cost);
                dashColor = 0xE0A0FF;
            } else {
                dashLine = Component.translatable("hud.void_ascension.ability_ready", dash.displayName(),
                        VoidKeyMappings.VOID_DASH.getTranslatedKeyMessage());
                dashColor = READY;
            }
        } else {
            dashLine = null;
        }

        int textW = Math.max(ICON + 3 + Math.max(font.width(brand), font.width(tierLine)),
                Math.max(font.width(essenceLine), font.width(nextLine)));
        if (reqLine != null) textW = Math.max(textW, font.width(reqLine));
        if (dashLine != null) textW = Math.max(textW, font.width(dashLine));
        if (warnLine != null) textW = Math.max(textW, font.width(warnLine));
        panelW = Math.max(MIN_W, textW + 2 * PAD + 1);
        panelH = PAD + ICON + 3 + 5 + LINE * 2 + (reqLine != null ? LINE : 0) + 6 + (dashLine != null ? LINE : 0) + PAD - 2;
    }

    private static Component warning(ClientVoidData.Feedback fb) {
        AbilityDefinition def = VoidAbilities.get(fb.abilityId());
        Component name = def != null ? def.displayName() : Component.literal(fb.abilityId());
        return switch (fb.result()) {
            case NOT_ENOUGH_ESSENCE -> Component.translatable("hud.void_ascension.warn.no_essence", fb.available(), fb.required());
            case ON_COOLDOWN -> Component.translatable("hud.void_ascension.warn.cooldown", name,
                    String.format(Locale.ROOT, "%.1f", fb.cooldownTicks() / 20.0));
            case LOCKED -> Component.translatable("hud.void_ascension.warn.locked", name);
            case NOT_INITIALIZED -> Component.translatable("hud.void_ascension.warn.dormant");
            default -> Component.translatable("hud.void_ascension.warn.denied", name);
        };
    }

    /** Readiness for the next tier: the lower of level progress and Essence progress (1 = both met). */
    static float readiness(EvolutionRequirements.Check c) {
        float lv = c.requiredLevel() <= 0 ? 1F : Math.min(1F, c.level() / (float) c.requiredLevel());
        float es = c.requiredEssence() <= 0 ? 1F : Math.min(1F, c.essence() / (float) c.requiredEssence());
        return Math.min(lv, es);
    }

    /** Requirement check from synced data, for display only (the server re-checks everything). */
    static EvolutionRequirements.Check clientCheck() {
        VoidPlayerData d = ClientVoidData.get();
        Minecraft mc = Minecraft.getInstance();
        boolean core = !VoidConfig.get(VoidConfig.EVOLUTION_REQUIRES_CARRIED_CORE)
                || (mc.player != null && CoreService.hasActiveCore(mc.player));
        return EvolutionRequirements.evaluate(d.isInitialized(), core, d.getTier(), d.getEvolutionLevel(), d.getEssence(),
                EvolutionTable::get);
    }

    /** Fraction of the way from the current level to the next (1 at max level). */
    static float levelProgress(VoidPlayerData data) {
        int lvl = data.getEvolutionLevel();
        if (lvl >= ProgressionService.maxLevel()) return 1.0F;
        long lo = ProgressionService.totalXpForLevel(lvl), hi = ProgressionService.totalXpForLevel(lvl + 1);
        return hi <= lo ? 1.0F : Math.max(0F, Math.min(1F, (data.getVoidExperience() - lo) / (float) (hi - lo)));
    }
}
